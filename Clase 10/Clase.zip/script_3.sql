﻿
SELECT clave, activo FROM usuario
WHERE nombre = 'sariana7602'
